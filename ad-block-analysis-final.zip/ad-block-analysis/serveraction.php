<?php
	error_reporting(error_reporting() & ~E_NOTICE);
	include('dbcon.php');
	
	$avalue=$_POST['avalue'];	
	
	switch ($avalue) 
	{
    	case "1":		
		
		$ntitle=$_POST['ntitle'];
		$nname=$_POST['nname'];
		
		$file1=$_FILES['file']['tmp_name'];
		$data1= addslashes(file_get_contents($_FILES['file']['tmp_name']));
		$data_name1= addslashes($_FILES['file']['name']);
		move_uploaded_file($_FILES["file"]["tmp_name"],"SNews/" . $_FILES["file"]["name"]);
		$file="SNews/" . $_FILES["file"]["name"];			
		
		$ndesc=$_POST['ndesc'];	
		$ndate=$_POST['ndate'];					
	
		$cmd="select * from snews where ntitle='$ntitle' AND nname='$nname'";
		$cmd1=mysql_query($cmd);
		if(mysql_fetch_array($cmd1))
		{
			header("location:SHome.php?msg2=No");
		}
		else 
		{			
			$query="insert into snews(ntitle,nname,nimage,ndesc,ndate) values('$ntitle','$nname','$file','$ndesc','$ndate')";
			if(mysql_query($query))
			{
				header("location:SHome.php?msg1=Yes");
			}			
		}				        
        break;	
		
		case "2":	
		
		$nid=$_POST['nid'];	
		$ntitle=$_POST['ntitle'];
		$nname=$_POST['nname'];	
		$ndesc=$_POST['ndesc'];	
					
		$query="update snews set ntitle='$ntitle',nname='$nname',ndesc='$ndesc' where nid='$nid'";
		if(mysql_query($query))
		{
			header("location:SViewNews.php?msg1=Yes");
		}						        
        break;		
			 	
    	default:
        header("location:index.php");	
	}	
	
?>
