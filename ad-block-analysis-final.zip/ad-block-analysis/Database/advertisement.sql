-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 13, 2024 at 08:40 AM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 5.6.38

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `advertisement`
--

-- --------------------------------------------------------

--
-- Table structure for table `ads`
--

CREATE TABLE `ads` (
  `adid` int(3) NOT NULL,
  `uid` varchar(3) NOT NULL,
  `atype1` varchar(25) NOT NULL,
  `atype2` varchar(25) NOT NULL,
  `atype3` varchar(25) NOT NULL,
  `atype4` varchar(25) NOT NULL,
  `atype5` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ads`
--

INSERT INTO `ads` (`adid`, `uid`, `atype1`, `atype2`, `atype3`, `atype4`, `atype5`) VALUES
(1, '1', '', '', 'Gaming', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `content`
--

CREATE TABLE `content` (
  `id` int(100) NOT NULL,
  `mid` varchar(250) NOT NULL,
  `mname` varchar(250) NOT NULL,
  `acategory` varchar(250) NOT NULL,
  `title` longtext NOT NULL,
  `name` longtext NOT NULL,
  `cdetails` longtext NOT NULL,
  `image` longblob NOT NULL,
  `adate` varchar(500) NOT NULL,
  `rank` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `content`
--

INSERT INTO `content` (`id`, `mid`, `mname`, `acategory`, `title`, `name`, `cdetails`, `image`, `adate`, `rank`) VALUES
(1, '1', 'John', 'Sports', 'Freepik', 'BasketBall', 'Basketball, game played between two teams of five players each on a rectangular court, usually indoors. Each team tries to score by tossing the ball through the opponentâ€™s goal, an elevated horizontal hoop and net called a basket.', 0x436f6e74656e742f6261736b657462616c6c2e6a7067, '11/04/2024', '0'),
(2, '2', 'Kumar', 'Gaming', 'Techspot', 'RummyCircle', 'RummyCircle, an Indian online skill gaming platform, today announced the launch of two new TVCs featuring its brand ambassador Hrithik Roshan. The new TVCs are built on brandâ€™s successful campaign â€œRaho Ek Kadam Aageâ€, highlighting the companyâ€™s vision to redefine online rummy and skill gaming in India.', 0x436f6e74656e742f72756d6d79636972636c652e6a7067, '11/04/2024', '1');

-- --------------------------------------------------------

--
-- Table structure for table `media`
--

CREATE TABLE `media` (
  `mid` int(250) NOT NULL,
  `mname` varchar(250) NOT NULL,
  `lid` varchar(250) NOT NULL,
  `lpass` varchar(250) NOT NULL,
  `cname` varchar(250) NOT NULL,
  `address` longtext NOT NULL,
  `email` varchar(250) NOT NULL,
  `city` varchar(250) NOT NULL,
  `state` varchar(250) NOT NULL,
  `pcode` varchar(250) NOT NULL,
  `cno` varchar(250) NOT NULL,
  `acategory` varchar(250) NOT NULL,
  `status` varchar(250) NOT NULL,
  `rdate` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `media`
--

INSERT INTO `media` (`mid`, `mname`, `lid`, `lpass`, `cname`, `address`, `email`, `city`, `state`, `pcode`, `cno`, `acategory`, `status`, `rdate`) VALUES
(1, 'John', 'john', '12345', 'J Sports ', '4/50,\r\n56 Street', 'john@gmail.com', 'Salem', 'Tamil Nadu', '636009', '9790269325', 'Sports', 'Yes', '11/04/2024'),
(2, 'Kumar', 'kumar', '54321', 'K-Gaming', '5/20,\r\nKS Street', 'kumar@gmail.com', 'Salem', 'Tamil Nadu', '636009', '9790269326', 'Gaming', 'Yes', '11/04/2024');

-- --------------------------------------------------------

--
-- Table structure for table `snews`
--

CREATE TABLE `snews` (
  `nid` int(100) NOT NULL,
  `ntitle` varchar(250) NOT NULL,
  `nname` varchar(250) NOT NULL,
  `nimage` longblob NOT NULL,
  `ndesc` longtext NOT NULL,
  `ndate` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `snews`
--

INSERT INTO `snews` (`nid`, `ntitle`, `nname`, `nimage`, `ndesc`, `ndate`) VALUES
(1, 'Online Game', 'Precise Targeting', 0x534e6577732f5072656369736520546172676574696e672e6a7067, 'Wiz Khalifa, an American rapper, promoted his 2050 Tour via dynamic ads in several game titles across Xbox 360 and PS3 consoles. Based on geo-targeting, the promotion appeared in selected US cities, giving gamers the opportunity to buy tickets earlier.', '13/04/2024');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `uid` int(100) NOT NULL,
  `uname` varchar(250) NOT NULL,
  `lid` varchar(250) NOT NULL,
  `lpass` varchar(250) NOT NULL,
  `gender` varchar(250) NOT NULL,
  `age` varchar(250) NOT NULL,
  `address` longtext NOT NULL,
  `email` varchar(250) NOT NULL,
  `city` varchar(250) NOT NULL,
  `state` varchar(250) NOT NULL,
  `pcode` varchar(250) NOT NULL,
  `cno` varchar(250) NOT NULL,
  `rdate` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`uid`, `uname`, `lid`, `lpass`, `gender`, `age`, `address`, `email`, `city`, `state`, `pcode`, `cno`, `rdate`) VALUES
(1, 'raja', 'raja', '67890', 'Male', '28', '5/1080,\r\nRS Street', 'raja@gmail.com', 'Salem', 'Tamil Nadu', '636009', '9790269325', '11/04/2024');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `ads`
--
ALTER TABLE `ads`
  ADD PRIMARY KEY (`adid`);

--
-- Indexes for table `content`
--
ALTER TABLE `content`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `media`
--
ALTER TABLE `media`
  ADD PRIMARY KEY (`mid`);

--
-- Indexes for table `snews`
--
ALTER TABLE `snews`
  ADD PRIMARY KEY (`nid`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`uid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `ads`
--
ALTER TABLE `ads`
  MODIFY `adid` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `content`
--
ALTER TABLE `content`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `media`
--
ALTER TABLE `media`
  MODIFY `mid` int(250) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `snews`
--
ALTER TABLE `snews`
  MODIFY `nid` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `uid` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
