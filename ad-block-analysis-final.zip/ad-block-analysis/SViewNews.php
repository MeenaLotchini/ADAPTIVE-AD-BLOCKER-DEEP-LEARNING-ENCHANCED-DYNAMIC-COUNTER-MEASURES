﻿<?php
error_reporting(error_reporting() & ~E_NOTICE);
if($_REQUEST['msg1']!=null)
{
	 echo"<script>alert('Server News Update Successfully...!')</script>";
}
if($_REQUEST['msg2']!=null)
{
	 echo"<script>alert('Server News Delete Successfully...!')</script>";
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Ad-Block-Analysis</title>
<meta name="keywords" content="" />
<meta name="description" content="" />

<link href="css/tooplate_style.css" rel="stylesheet" type="text/css" />

<script type="text/javascript" src="js/swfobject.js"></script>
<script type="text/javascript">
	var flashvars = {};
	flashvars.xml_file = "photo_list.xml";
	var params = {};
	params.wmode = "transparent";
	var attributes = {};
	attributes.id = "slider";
	swfobject.embedSWF("flash_slider.swf", "flash_grid_slider", "440", "220", "9.0.0", false, flashvars, params, attributes);
</script>

<link rel="stylesheet" type="text/css" href="css/ddsmoothmenu.css" />

<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/ddsmoothmenu.js"></script>

<script type="text/javascript">

ddsmoothmenu.init({
	mainmenuid: "tooplate_menu", //menu DIV id
	orientation: 'h', //Horizontal or vertical menu: Set to "h" or "v"
	classname: 'ddsmoothmenu', //class added to menu's outer DIV
	//customtheme: ["#1c5a80", "#18374a"],
	contentsource: "markup" //"markup" or ["container_id", "path_to_menu_file"]
})

</script>
    
</head>
<body>

<div id="tooplate_wrapper">
	<div id="tooplate_header">
	  <div id="tooplate_menu" class="ddsmoothmenu">
		
   	  <ul>
               	<li><a href="SHome.php" class="selected">Home</a></li>
                <li><a href="SViewNews.php" class="selected">View News</a></li>                
               	<li><a href="#">Media</a>
                    <ul>
                        <li><a href="SMediaDetails.php">Media Details</a></li>
                        <li><a href="SViewMediaService.php">Media Service</a></li>                       
                	</ul>
              	</li>    
                <li><a href="SUserDetails.php">User</a></li>                
                <li><a href="Server.php">Logout</a></li>
            </ul>
			
            <br style="clear: left" />
        </div> <!-- end of tooplate_menu -->
  </div>
    
    
    
    <div id="tooplate_middle">
        <div id="mid_slider">
            <div id="flash_grid_slider">View Server News...</div>
            <div id="work">
               <table width="0" height="0" border="1">
  		<tr align="center" bgcolor="#FFFFFF" style="font-weight:bold; color:#00F">
        <th>News ID</th>
        <th>News Title</th>
        <th>News Name</th>
        <th>News Image</th> 
        <th>News Date</th>
        <th>Edit</th>
        <th>Delete</th>                       
  		</tr>
        <?php	 
		error_reporting(error_reporting() & ~E_NOTICE);
 		include('dbcon.php');		 
  		
  		$result=mysql_query("select * from  snews");
		while($rec = mysql_fetch_assoc($result))
		{
			 print"<tr align='center'>";
			 print"<td>";
			 echo $rec['nid'];
			 print"</td><td>";   			 
	 		 echo $rec['ntitle'];
			 print"</td><td>";
	 		 echo $rec['nname'];
	 		 print"</td><td>";	
			 echo "<img src='".$rec['nimage']."' width='75' height='75'/>";
	 		 print"</td><td>";
			 echo $rec['ndate'];
	 		 print"</td><td>";			 
			 echo "<a href='SEditNews.php?nid=".$rec['nid']."'>Edit</a>";	
			 print"</td><td>";			 
			 echo "<a href='SDeleteNews.php?nid=".$rec['nid']."'>Delete</a>";		  							 		 			 		
	 		 print"</td>";
	 		 print"</tr>";   
		}   
		
	  ?>  
		</table>  
        	</div>      
        </div>		
      <div id="mid_left">
            <div id="mid_title">Latest News</div>
         	<marquee behavior="scroll" direction="up" onMouseOver="this.stop();" onMouseOut="this.start();">            
           <?php	 
			error_reporting(error_reporting() & ~E_NOTICE);
 			include('dbcon.php');
			$date=date("d/m/Y");		 
  		
  			$result=mysql_query("select * from snews where ndate='$date'");
			while($rec = mysql_fetch_assoc($result))
			{
			?>
        	<div id="snews">
            	<div id="t1">Title:<?php echo $rec['ntitle']; ?></div>
                <div id="t2">Name:<?php echo $rec['ntitle']; ?></div>
                <div id="t3"><img src="<?php echo $rec['nimage']; ?>" width="30" height="30" /></div>
                <div id="t4">Details:<?php echo $rec['ndesc']; ?></div>
                <div id="t5">Date:<?php echo $rec['ndate']; ?></div>
            </div>
			<?php
			}
			?>  
            </marquee>
       </div>
		
        <div class="cleaner"></div>
    </div> <!-- end of tooplate_middle -->
    
    <div id="tooplate_footer"></div>
</div>

</body>
</html>