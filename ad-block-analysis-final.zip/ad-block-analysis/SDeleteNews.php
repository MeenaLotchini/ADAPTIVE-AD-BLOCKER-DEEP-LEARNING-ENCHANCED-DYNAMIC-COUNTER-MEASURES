<?php
	error_reporting(error_reporting() & ~E_NOTICE);
	include('dbcon.php');
	
	$query="delete from snews where nid='".$_REQUEST['nid']."'";
	if(mysql_query($query))
	{
		header("location:SViewNews.php?msg2=Yes");
	}		
?>
