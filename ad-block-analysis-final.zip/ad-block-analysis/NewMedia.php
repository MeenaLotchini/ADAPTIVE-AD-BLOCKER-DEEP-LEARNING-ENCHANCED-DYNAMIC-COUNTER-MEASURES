﻿<?php
error_reporting(error_reporting() & ~E_NOTICE);
if($_REQUEST['msg1']!=null)
{
	 echo"<script>alert('Media Register Successfully...!')</script>";	
}
if($_REQUEST['msg2']!=null)
{
	 echo"<script>alert('Already Media Registered...!')</script>";	
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Ad-Block-Analysis</title>
<meta name="keywords" content="" />
<meta name="description" content="" />

<link href="css/tooplate_style.css" rel="stylesheet" type="text/css" />

<script type="text/javascript" src="js/swfobject.js"></script>
<script type="text/javascript">
	var flashvars = {};
	flashvars.xml_file = "photo_list.xml";
	var params = {};
	params.wmode = "transparent";
	var attributes = {};
	attributes.id = "slider";
	swfobject.embedSWF("flash_slider.swf", "flash_grid_slider", "440", "220", "9.0.0", false, flashvars, params, attributes);
</script>

<link rel="stylesheet" type="text/css" href="css/ddsmoothmenu.css" />

<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/ddsmoothmenu.js"></script>

<script type="text/javascript">

ddsmoothmenu.init({
	mainmenuid: "tooplate_menu", //menu DIV id
	orientation: 'h', //Horizontal or vertical menu: Set to "h" or "v"
	classname: 'ddsmoothmenu', //class added to menu's outer DIV
	//customtheme: ["#1c5a80", "#18374a"],
	contentsource: "markup" //"markup" or ["container_id", "path_to_menu_file"]
})

</script>
<script language="javascript">
function alogin(thisform)
{
	with(thisform)
	{	    
		if(mname.value=="")
		{ 
		alert("Please Enter Media Name...!")
		mname.focus();
		return false 
		}
	}
	with(thisform)
	{	    
		if(lid.value=="")
		{ 
		alert("Please Enter Media Login ID...!")
		lid.focus();
		return false 
		}
	}
	with(thisform)
	{	    
		if(lpass.value=="")
		{ 
		alert("Please Enter Media Login Password...!")
		lpass.focus();
		return false 
		}
	}
	with(thisform)
	{	    
		if(cname.value=="")
		{ 
		alert("Please Enter Company Name...!")
		cname.focus();
		return false 
		}
	}
	with(thisform)
	{	    
		if(address.value=="")
		{ 
		alert("Please Enter Address..!")
		address.focus();
		return false 
		}
	}
	with(thisform)
	{	    
		if(email.value=="")
		{ 
		alert("Please Enter E-Mail ID...!")
		email.focus();
		return false 
		}
	}
	with(thisform)
	{	    
		if(city.value=="")
		{ 
		alert("Please Select City Name..!")
		city.focus();
		return false 
		}
	}
	with(thisform)
	{	    
		if(state.value=="")
		{ 
		alert("Please Select State Name...!")
		state.focus();
		return false 
		}
	}
	with(thisform)
	{	    
		if(pcode.value=="")
		{ 
		alert("Please Enter Pin Code..!")
		pcode.focus();
		return false 
		}
	}
	with(thisform)
	{	    
		if(cno.value=="")
		{ 
		alert("Please Enter Contact Number...!")
		cno.focus();
		return false 
		}
	}
	with(thisform)
	{	    
		if(acategory.value=="")
		{ 
		alert("Please Select Category...!")
		acategory.focus();
		return false 
		}
	}	

}
</script>
    
</head>
<body>

<div id="tooplate_wrapper">
	<div id="tooplate_header">
	  <div id="tooplate_menu" class="ddsmoothmenu">
		
   	  <ul>
               	<li><a href="index.php" class="selected">Home</a></li>
                <li><a href="#">Service</a>
                    <ul>
                    	<li><a href="Server.php">Server</a></li>
                        <li><a href="Media.php">Media</a></li>
                        <li><a href="NewMedia.php">New Meida</a></li>
                        <li><a href="User.php">User</a></li>
                        <li><a href="NewUser.php">New User</a></li>
                	</ul>
              	</li>
				<li><a href="#">About Us</a></li>                             
                <li><a href="#">Contact</a></li>
            </ul>
			
            <br style="clear: left" />
        </div> <!-- end of tooplate_menu -->
  </div>
    
    
    <div id="tooplate_middle">
        <div id="mid_slider">
            <div id="flash_grid_slider"><center>New Media Register Form</center></div>
            <div id="login">
        <form action="mediaaction.php" method="post" onsubmit="return alogin(this);">
    <table width="241" height="411" border="0">
  <tr>
    <td><div align="center">      
      <input type="text" name="mname" id="txt" placeholder="Enter Media Name" />
    </div></td>
  </tr>
  <tr>
    <td><div align="center">      
      <input type="text" name="lid" id="txt" placeholder="Enter Media Login Name" />
    </div></td>
  </tr>
  <tr>
    <td><div align="center">      
      <input type="password" name="lpass" id="txt" placeholder="Enter  Media Login Password" />
    </div></td>
  </tr>
  <tr>
    <td><div align="center">      
     <input type="text" name="cname" id="txt" placeholder="Enter Company Name" />
    </div></td>
  </tr>  
  <tr>
    <td><div align="center">
      <textarea name="address" id="atxt" placeholder="Enter Address"></textarea>
    </div></td>
  </tr>
   <tr>
    <td><div align="center">
     <input type="text" name="email" id="txt" placeholder="Enter Email ID" />
    </div></td>
  </tr>
  <tr>
    <td><div align="center">      
      <select name="city" id="txt">
     <option value="">Select City</option>
     <option value="Chennai">Chennai</option>
     <option value="Salem">Salem</option>
     </select>
    </div></td>
  </tr>
  <tr>
    <td><div align="center">      
      <select name="state" id="txt">
     <option value="">Select State</option>
     <option value="Tamil Nadu">Tamil Nadu</option>
     <option value="Kerala">Kerala</option>
     </select>
    </div></td>
  </tr>
  <tr>
    <td><div align="center">      
      <input type="text" name="pcode" id="txt" maxlength="6" placeholder="Enter Pincode" />
    </div></td>
  </tr>
  <tr>
    <td><div align="center">      
      <input type="text" name="cno" id="txt" maxlength="10" placeholder="Enter Contact No" />
    </div></td>
  </tr> 
   <tr>
    <td><div align="center">      
     <select name="acategory" id="txt">
     <option value="">Select Category</option>
     <option value="Sports">Sports</option>
     <option value="Gaming">Gaming</option>
     <option value="Education">Education</option>
     <option value="Job">Job</option>
     </select>
    </div></td>
  </tr>   
  <tr>
    <td><div align="center">      
    <input type="hidden" name="avalue" value="1" id="btn"/>
      <input type="submit" name="Submit" value="Sign up" id="btn"/>
      <input type="reset" name="Clear" value="Clear" id="btn"/>
    </div></td>
  </tr>
</table>

    </form>           
        </div>      
        </div>		
        <div id="mid_left">
            <div id="mid_title">Latest News</div>
            <marquee behavior="scroll" direction="up" onMouseOver="this.stop();" onMouseOut="this.start();">            
            <?php	 
			error_reporting(error_reporting() & ~E_NOTICE);
 			include('dbcon.php');
			$date=date("d/m/Y");		 
  		
  			$result=mysql_query("select * from snews where ndate='$date'");
			while($rec = mysql_fetch_assoc($result))
			{
			?>
        	<div id="snews">
            	<div id="t1">Title:<?php echo $rec['ntitle']; ?></div>
                <div id="t2">Name:<?php echo $rec['ntitle']; ?></div>
                <div id="t3"><img src="<?php echo $rec['nimage']; ?>" width="30" height="30" /></div>
                <div id="t4">Details:<?php echo $rec['ndesc']; ?></div>
                <div id="t5">Date:<?php echo $rec['ndate']; ?></div>
            </div>
			<?php
			}
			?>  
            </marquee>
            <div id="learn_more"></div>
        </div>
		
        <div class="cleaner"></div>
    </div>   
    
    <div id="tooplate_footer"></div>
</div>

</body>
</html>