<?php
	session_start();
?>
<?php
	error_reporting(error_reporting() & ~E_NOTICE);
	include('dbcon.php');
	
	$avalue=$_POST['avalue'];	
	
	switch ($avalue) 
	{
    	case "1":		
		$lid=$_POST['lid'];
		$lpass=$_POST['lpass'];
		
		if(($lid=="server") && ($lpass=="server"))
    	{
			header("location:SHome.php");			
		}		
		else
		{						
			header('location:Server.php?msg2=No');					
		}	        
        break; 			
		   	
    	default:
        header("location:index.php");	
	}	
	
?>
