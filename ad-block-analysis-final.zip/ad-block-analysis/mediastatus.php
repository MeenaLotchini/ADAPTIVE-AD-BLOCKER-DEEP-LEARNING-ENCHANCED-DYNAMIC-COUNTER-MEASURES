<?php
	error_reporting(error_reporting() & ~E_NOTICE);
	include('dbcon.php');
	
	$mid=$_REQUEST['mid'];
	$status=$_REQUEST['status'];
	
	if($status=="Yes")
	{
		$query="update media set status='No' where mid='$mid'";
		if(mysql_query($query))
		{
			header("location:SMediaDetails.php?msg1=Yes");
		}	
	}
	else
	{
		$query="update media set status='Yes' where mid='$mid'";
		if(mysql_query($query))
		{
			header("location:SMediaDetails.php?msg2=Yes");
		}	
	}
	
		
?>
