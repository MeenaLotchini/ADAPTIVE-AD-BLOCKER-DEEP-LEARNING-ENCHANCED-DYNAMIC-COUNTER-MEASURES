<?php
	error_reporting(error_reporting() & ~E_NOTICE);
	include('dbcon.php');
	
	$avalue=$_POST['avalue'];	
	
	switch ($avalue) 
	{	
		case "1":
		
		$uid=$_POST['uid'];
		
		$x1=$_POST['checkbox1'];
		$x2=$_POST['checkbox2'];
		$x3=$_POST['checkbox3'];
		$x4=$_POST['checkbox4'];
		$x5=$_POST['checkbox5'];
		
		//print $uid;
		//print $x2;
		
		$query="select * from ads where uid='$uid'";
		$cmd=mysql_query($query);
		if(mysql_num_rows($cmd) > 0)
		{		
			$query="update ads set atype1='$x1',atype2='$x2',atype3='$x3',atype4='$x4',atype5='$x5' where uid='$uid'";
			if(mysql_query($query))
			{			
				echo "<script type='text/javascript'> document.location ='UViewService.php'; </script>";	
			}			
		}
		else 
		{		
			$query="insert into ads(uid,atype1,atype2,atype3,atype4,atype5) values('$uid','$x1','$x2','$x3','$x4','$x5')";
			if(mysql_query($query))
			{			
				//echo "<script type='text/javascript'> document.location ='UViewService.php'; </script>";	
				header("location:UViewService.php");	
			}	
		}				
        break;			      	
		  	
    	default:
        header("location:index.php");	
	}	
	
?>
