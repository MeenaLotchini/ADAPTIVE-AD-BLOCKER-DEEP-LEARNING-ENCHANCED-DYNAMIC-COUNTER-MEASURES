﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Ad-Block-Analysis</title>
<meta name="keywords" content="" />
<meta name="description" content="" />

<link href="css/tooplate_style.css" rel="stylesheet" type="text/css" />

<script type="text/javascript" src="js/swfobject.js"></script>
<script type="text/javascript">
	var flashvars = {};
	flashvars.xml_file = "photo_list.xml";
	var params = {};
	params.wmode = "transparent";
	var attributes = {};
	attributes.id = "slider";
	swfobject.embedSWF("flash_slider.swf", "flash_grid_slider", "440", "220", "9.0.0", false, flashvars, params, attributes);
</script>

<link rel="stylesheet" type="text/css" href="css/ddsmoothmenu.css" />

<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/ddsmoothmenu.js"></script>

<script type="text/javascript">

ddsmoothmenu.init({
	mainmenuid: "tooplate_menu", //menu DIV id
	orientation: 'h', //Horizontal or vertical menu: Set to "h" or "v"
	classname: 'ddsmoothmenu', //class added to menu's outer DIV
	//customtheme: ["#1c5a80", "#18374a"],
	contentsource: "markup" //"markup" or ["container_id", "path_to_menu_file"]
})

</script>
    
</head>
<body>

<div id="tooplate_wrapper">
	<div id="tooplate_header">
	  <div id="tooplate_menu" class="ddsmoothmenu">
		
   	  <ul>
               	<li><a href="index.php" class="selected">Home</a></li>
                <li><a href="#">Service</a>
                    <ul>
                    	<li><a href="Server.php">Server</a></li>
                        <li><a href="Media.php">Media</a></li>
                        <li><a href="NewMedia.php">New Meida</a></li>
                        <li><a href="User.php">User</a></li>
                        <li><a href="NewUser.php">New User</a></li>
                	</ul>
              	</li>  
				<li><a href="#">About Us</a></li>                             
                <li><a href="#">Contact</a></li>
            </ul>
			
            <br style="clear: left" />
        </div> <!-- end of tooplate_menu -->
  </div>
    
    <div id="tooplate_social">
    	<a href="#"><img src="images/facebook.png" alt="facebook" /></a>
        <a href="#"><img src="images/stumbleupon.png" alt="stumbleupon" /></a>
        <a href="#"><img src="images/feed.png" alt="feed" /></a>
        <a href="#"><img src="images/twitter.png" alt="twitter" /></a>        
    </div>
    
    <div id="tooplate_middle">
        <div id="mid_slider">
            <div id="mid_title"></div>
            <div id="work">
				
            </div>
        </div>		
        <div id="mid_left">
            <div id="mid_title">Latest News</div>
            <marquee behavior="scroll" direction="up">            
            <?php	 
			error_reporting(error_reporting() & ~E_NOTICE);
 			include('dbcon.php');
			$date=date("d/m/Y");		 
  		
  			$result=mysql_query("select * from snews where ndate='$date'");
			while($rec = mysql_fetch_assoc($result))
			{
			?>
        	<div id="snews">
            	<div id="t1">Title:<?php echo $rec['ntitle']; ?></div>
                <div id="t2">Name:<?php echo $rec['ntitle']; ?></div>
                <div id="t3"><img src="<?php echo $rec['nimage']; ?>" width="30" height="30" /></div>
                <div id="t4">Details:<?php echo $rec['ndesc']; ?></div>
                <div id="t5">Date:<?php echo $rec['ndate']; ?></div>
            </div>
			<?php
			}
			?>  
            </marquee>
            <div id="learn_more"></div>
        </div>
		
        <div class="cleaner"></div>
    </div> <!-- end of tooplate_middle -->
    
    <div id="tooplate_main_top"></div>
    <div id="tooplate_main">
        	
        <div class="col_fw">
           
			
            <div class="cleaner"></div>
        </div>
		
		<div class="cleaner"></div>       
	</div> 
	
    <div id="tooplate_main_bottom"></div>
    <div id="tooplate_footer"></div>
</div>

</body>
</html>