<?php
	session_start();
?>
<?php
	error_reporting(error_reporting() & ~E_NOTICE);
	include('dbcon.php');
	
	$avalue=$_POST['avalue'];	
	
	switch ($avalue) 
	{
    	case "1":
				
		$mname=$_POST['mname'];
		$lid=$_POST['lid'];
		$lpass=$_POST['lpass'];
		$cname=$_POST['cname'];
		$address=$_POST['address'];
		$email=$_POST['email'];
		$city=$_POST['city'];
		$state=$_POST['state'];
		$pcode=$_POST['pcode'];
		$cno=$_POST['cno'];
		$acategory=$_POST['acategory'];
		$rdate=date("d/m/Y");
				
		$cmd="select * from media where mname='$mname' OR email='$email' OR cname='$cname'";
		$cmd1=mysql_query($cmd);		
		if($rs=mysql_fetch_array($cmd1))
    	{
			header("location:NewMedia.php?msg2=No");						
		}		
		else
		{
			$cmd="insert into media(mname,lid,lpass,cname,address,email,city,state,pcode,cno,acategory,status,rdate) values('$mname','$lid','$lpass','$cname','$address','$email','$city','$state','$pcode','$cno','$acategory','No','$rdate')";
			if(mysql_query($cmd))
			{
				header("location:NewMedia.php?msg1=Yes");	
			}
		}	        
        break;	
		
		case "2":	
			
		$lid=$_POST['lid'];
		$lpass=$_POST['lpass'];
				
		$cmd="select * from media where lid='".$lid."' AND lpass='".$lpass."'";
		$cmd1=mysql_query($cmd);		
		if($rs=mysql_fetch_array($cmd1))
    	{
			if($rs['status']=='Yes')
			{
				$_SESSION['mid']=$rs['mid'];					
				$_SESSION['mname']=$rs['mname'];	
				$_SESSION['email']=$rs['email'];	
				$_SESSION['acategory']=$rs['acategory'];				
				
				header("location:MHome.php");				
			}
			else
			{
				header("location:Media.php?msg1=No");		
			}										
		}		
		else
		{
			header("location:Media.php?msg2=No");					
		}	        
        break;	
		
		case "3":		
		
		$mid=$_POST['mid'];
		$mname=$_POST['mname'];
		$acategory=$_POST['acategory'];
		$title=$_POST['title'];
		$name=$_POST['name'];
		$cdetails=$_POST['cdetails'];	
		
		$file1=$_FILES['file']['tmp_name'];
		$data1= addslashes(file_get_contents($_FILES['file']['tmp_name']));
		$data_name1= addslashes($_FILES['file']['name']);
		move_uploaded_file($_FILES["file"]["tmp_name"],"Content/" . $_FILES["file"]["name"]);
		$file="Content/" . $_FILES["file"]["name"];		
		
		$adate=$_POST['adate'];					
	
		$cmd="select * from content where mid='$mid' AND title='$title' AND name='$name'";
		$cmd1=mysql_query($cmd);
		if(mysql_fetch_array($cmd1))
		{
			header("location:MAddService.php?msg2=No");
		}
		else 
		{			
			$query="insert into content(mid,mname,acategory,title,name,cdetails,image,adate,rank) values('$mid','$mname','$acategory','$title','$name','$cdetails','$file','$adate','0')";
			if(mysql_query($query))
			{
				header("location:MAddService.php?msg1=Yes");
			}			
		}				        
        break;	
		
		case "4":	
		
		$id=$_POST['id'];	
		$title=$_POST['title'];
		$name=$_POST['name'];	
		$cdetails=$_POST['cdetails'];	
					
		$query="update content set title='$title',name='$name',cdetails='$cdetails' where id='$id'";
		if(mysql_query($query))
		{
			header("location:MEditService.php?msg1=Yes");
		}						        
        break;		
		   	
    	default:
        header("location:index.php");	
	}	
	
?>
