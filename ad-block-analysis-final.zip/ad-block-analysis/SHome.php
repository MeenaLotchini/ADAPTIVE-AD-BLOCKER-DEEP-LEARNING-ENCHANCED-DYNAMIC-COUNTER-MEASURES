﻿<?php
error_reporting(error_reporting() & ~E_NOTICE);
if($_REQUEST['msg1']!=null)
{
	 echo"<script>alert('Add Server News Successfully...!')</script>";
}
if($_REQUEST['msg2']!=null)
{
	 echo"<script>alert('Already This News Details Added...!')</script>";
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Ad-Block-Analysis</title>
<meta name="keywords" content="" />
<meta name="description" content="" />

<link href="css/tooplate_style.css" rel="stylesheet" type="text/css" />

<script type="text/javascript" src="js/swfobject.js"></script>
<script type="text/javascript">
	var flashvars = {};
	flashvars.xml_file = "photo_list.xml";
	var params = {};
	params.wmode = "transparent";
	var attributes = {};
	attributes.id = "slider";
	swfobject.embedSWF("flash_slider.swf", "flash_grid_slider", "440", "220", "9.0.0", false, flashvars, params, attributes);
</script>

<link rel="stylesheet" type="text/css" href="css/ddsmoothmenu.css" />

<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/ddsmoothmenu.js"></script>

<script type="text/javascript">

ddsmoothmenu.init({
	mainmenuid: "tooplate_menu", //menu DIV id
	orientation: 'h', //Horizontal or vertical menu: Set to "h" or "v"
	classname: 'ddsmoothmenu', //class added to menu's outer DIV
	//customtheme: ["#1c5a80", "#18374a"],
	contentsource: "markup" //"markup" or ["container_id", "path_to_menu_file"]
})

</script>
<script language="javascript">
function alogin(thisform)
{	
	with(thisform)
	{	    
		if(ntitle.value=="")
		{ 
		alert("Please Enter News Title...!")
		ntitle.focus();
		return false 
		}
	}
	with(thisform)
	{	    
		if(nname.value=="")
		{ 
		alert("Please Enter News Name...!")
		nname.focus();
		return false 
		}
	}
	with(thisform)
	{	    
		if(file.value=="")
		{ 
		alert("Please Select News Image...!")
		file.focus();
		return false 
		}
	}
	with(thisform)
	{	    
		if(ndesc.value=="")
		{ 
		alert("Please Enter News Description...!")
		ndesc.focus();
		return false 
		}
	}				
}
</script>
    
</head>
<body>

<div id="tooplate_wrapper">
	<div id="tooplate_header">
	  <div id="tooplate_menu" class="ddsmoothmenu">
		
   	  <ul>
               	<li><a href="SHome.php" class="selected">Home</a></li>
                <li><a href="SViewNews.php" class="selected">View News</a></li>                
               	<li><a href="#">Media</a>
                    <ul>
                        <li><a href="SMediaDetails.php">Media Details</a></li>
                        <li><a href="SViewMediaService.php">Media Service</a></li>                       
                	</ul>
              	</li>    
                <li><a href="SUserDetails.php">User</a></li>                
                <li><a href="Server.php">Logout</a></li>
            </ul>
			
            <br style="clear: left" />
        </div> <!-- end of tooplate_menu -->
  </div>
    
    
    
    <div id="tooplate_middle">
        <div id="mid_slider">
            <div id="flash_grid_slider">Add Server News...</div>
            <div id="work">
               <form action="serveraction.php" method="post" onsubmit="return alogin(this);" enctype="multipart/form-data">
                <table width="355" height="293" border="0">        	   
                 <tr>
        	      <td width="242"><div align="right">News Title:</div></td>
                  <td><input  type="text" name="ntitle" id="txt" /></td>
      	      	</tr>  
                 <tr>
        	      <td width="242"><div align="right">News Name:</div></td>
                  <td><input  type="text" name="nname" id="txt" /></td>
      	      	</tr>                
                 <tr>
        	      <td width="242"><div align="right">News Image:</div></td>
                  <td><input name="file" type="file" /></td>
      	      	</tr> 
                 <tr>
        	      <td width="242"><div align="right">News Description:</div></td>
                  <td><textarea name="ndesc" cols="" rows="" id="atxt"></textarea></td>
      	      	</tr> 
                 <tr>
        	      <td width="242"><div align="right">News Date:</div></td>
                  <td><input  type="text" name="ndate" id="txt" readonly="readonly" value="<?php echo date("d/m/Y"); ?>" /></td>
      	      	</tr>                  
                <tr>
        	      <td><div align="center">
        	        <input type="hidden" name="avalue" value="1" />
        	        <input type="submit" name="Submit" id="btn" value="ADD" />
      	        </div></td>
                  <td><div align="center">
                    <input type="reset" name="Clear" id="btn" value="CLEAR" />
                  </div></td>
      	      </tr>         	     
                </table>                    
                  </form> 
        	</div>      
        </div>		
      <div id="mid_left">
            <div id="mid_title">Latest News</div>
         	<marquee behavior="scroll" direction="up" onMouseOver="this.stop();" onMouseOut="this.start();">            
            <?php	 
			error_reporting(error_reporting() & ~E_NOTICE);
 			include('dbcon.php');
			$date=date("d/m/Y");		 
  		
  			$result=mysql_query("select * from snews where ndate='$date'");
			while($rec = mysql_fetch_assoc($result))
			{
			?>
        	<div id="snews">
            	<div id="t1">Title:<?php echo $rec['ntitle']; ?></div>
                <div id="t2">Name:<?php echo $rec['ntitle']; ?></div>
                <div id="t3"><img src="<?php echo $rec['nimage']; ?>" width="30" height="30" /></div>
                <div id="t4">Details:<?php echo $rec['ndesc']; ?></div>
                <div id="t5">Date:<?php echo $rec['ndate']; ?></div>
            </div>
			<?php
			}
			?>  
            </marquee>
       </div>
		
        <div class="cleaner"></div>
    </div> <!-- end of tooplate_middle -->
    
    <div id="tooplate_footer"></div>
</div>

</body>
</html>