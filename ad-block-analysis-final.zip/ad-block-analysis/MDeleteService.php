<?php
	error_reporting(error_reporting() & ~E_NOTICE);
	include('dbcon.php');
	
	$query="delete from content where id='".$_REQUEST['id']."'";
	if(mysql_query($query))
	{
		header("location:MViewService.php?msg2=Yes");
	}		
?>
