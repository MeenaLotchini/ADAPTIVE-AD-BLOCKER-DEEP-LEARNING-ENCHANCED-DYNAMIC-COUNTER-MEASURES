<?php
	session_start();
?>
<?php
	error_reporting(error_reporting() & ~E_NOTICE);
	include('dbcon.php');
	
	$avalue=$_POST['avalue'];	
	
	switch ($avalue) 
	{
    	case "1":
				
		$uname=$_POST['uname'];
		$lid=$_POST['lid'];
		$lpass=$_POST['lpass'];
		$gender=$_POST['gender'];
		$age=$_POST['age'];
		$address=$_POST['address'];
		$email=$_POST['email'];
		$city=$_POST['city'];
		$state=$_POST['state'];
		$pcode=$_POST['pcode'];
		$cno=$_POST['cno'];		
		$rdate=date("d/m/Y");
			
				
		$cmd="select * from user where uname='$uname' OR email='$email' OR cno='$cno'";
		$cmd1=mysql_query($cmd);		
		if($rs=mysql_fetch_array($cmd1))
    	{
			header("location:NewUser.php?msg2=No");						
		}		
		else
		{
			$cmd="insert into user(uname,lid,lpass,gender,age,address,email,city,state,pcode,cno,rdate) values('$uname','$lid','$lpass','$gender','$age','$address','$email','$city','$state','$pcode','$cno','$rdate')";
			if(mysql_query($cmd))
			{			
				header("location:NewUser.php?msg1=Yes");														
			}				
		}
			        
        break;	
		
		case "2":	
			
		$lid=$_POST['lid'];
		$lpass=$_POST['lpass'];
				
		$cmd="select * from user where lid='".$lid."' AND lpass='".$lpass."'";
		$cmd1=mysql_query($cmd);		
		if($rs=mysql_fetch_array($cmd1))
    	{
			$_SESSION['uid']=$rs['uid'];					
			$_SESSION['uname']=$rs['uname'];	
			$_SESSION['email']=$rs['email'];					
				
			header("location:UHome.php");													
		}		
		else
		{
			header("location:User.php?msg2=No");					
		}	        
        break;	
		
		case "3":	
			
		$uid=$_POST['uid'];	
		$opass=$_POST['opass'];
		$npass=$_POST['npass'];
				
		$cmd="update user set lpass='$npass' where uid='$uid' AND lpass='$opass'";				
		if(mysql_query($cmd))
    	{		
			header("location:UChangePassword.php?msg1=Yes");							
		}
		else
		{
			header("location:UChangePassword.php?msg2=No");
		}
        break;	
		   	
    	default:
        header("location:index.php");	
	}	
	
?>
